package uk.ncl.CSC8016.jackbergus.coursework.project3.events;

public enum TopicUpdatesType { // THIS CLASS SHALL NOT BE CHANGED
    NewTopicPublished,
    NewCommentPublishedInToipic,
    TopicDeleted,
    QueryGetAllTopicNamesSortedByDate,
    QueryGetAllTopicIDsSortedByDate,
    QueryGetAllTopicPosts
}
