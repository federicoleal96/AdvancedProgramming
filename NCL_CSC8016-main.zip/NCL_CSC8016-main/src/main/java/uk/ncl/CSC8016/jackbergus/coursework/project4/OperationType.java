package uk.ncl.CSC8016.jackbergus.coursework.project4;

public enum OperationType {
    Pay,
    Withdraw,
    Commit,
    Abort
}
