package uk.ncl.CSC8016.jackbergus.coursework.project1;

public enum OperationType {
    Pay,
    Withdraw,
    Commit,
    Abort
}
